package org.formacio.repositori;


public interface PersonaRepository  {

}
