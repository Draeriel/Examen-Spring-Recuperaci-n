 create sequence hibernate_sequence;
 create table t_persones (per_id bigint not null, per_nom varchar(255), primary key (per_id))